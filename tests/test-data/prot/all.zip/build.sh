sourmash compute -k 57 *_protein.faa.gz --scaled=100 -f --input-is-protein  --no-dna --outdir protein --protein
sourmash compute -k 57 *_protein.faa.gz --scaled=100 -f --input-is-protein  --no-dna --outdir hp --hp
sourmash compute -k 57 *_protein.faa.gz --scaled=100 -f --input-is-protein  --no-dna --outdir dayhoff --dayhoff
